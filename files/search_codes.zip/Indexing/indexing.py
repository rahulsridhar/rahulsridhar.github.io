import numpy as np
import nltk
#import matplotlib.pyplot as plt
from collections import defaultdict
import operator
import bs4
from bs4 import BeautifulSoup
import re
import json
import os
from nltk.stem import porter, PorterStemmer, WordNetLemmatizer
import hunspell
from nltk.tokenize import wordpunct_tokenize
import sys
import helper.crawler_frame
from helper.crawler_frame import is_valid
import urllib
from timeit import default_timer as timer
from itertools import chain

## Remove invalid files once and for all

invalid_ctr = 0 # Keep track of invalid files
i = 0
start_time = timer()
with open('Data/WEBPAGES_RAW/bookkeeping.tsv', 'r') as f1, open('Data/WEBPAGES_RAW/bookkeeping_valid.tsv', 'w') as f2:
    for line in f1:
        i += 1
        url_line = (line.strip()).split('\t')
        urlline = 'http://' + url_line[1]
        
        if is_valid(urlline):
            if(urlline != 'http://mondego.ics.uci.edu/datasets/maven-contents.txt'): # Huge file - ignore
                f2.writelines(url_line[0] + "\t" + urlline + "\n")
        else:
            invalid_ctr += 1
            continue
end_time = timer()
print "Elapsed time = ", end_time - start_time, "seconds"
print "Invalid = ", invalid_ctr + 1 # for maven-contents.txt
print "Total urls = ", i

## HTML Parser + Tokenizer + Indexer

fancy_tags = set(['meta', 'title', 'h1', 'h2', 'h3', 'h4', 'table', 'th', 'b', 'a'])
plain_indexer = defaultdict(list)
fancy_indexer = defaultdict(list)

def indexer(doc_id):
    '''
        Creates two inverted indices for the set of words (plain hits and fancy hits)
        in the corpus. Each posting contains the document id in which the word was found, its
        term frequency, tag, position, font size and capitalization information. 
    '''
    global doc_tf
    for item in doc_words:
        posting = doc_words[item]
        for i in range(len(posting)):
            tag = posting[i][0] # Extract tag
            if(str(tag.lower()) in fancy_tags):
                fancy_indexer[item].append([doc_id, posting[i], doc_tf[item]])
            else:
                plain_indexer[item].append([doc_id, posting[i], doc_tf[item]])

# Create objects for stemmer, lemmatizer and spell checker
port = PorterStemmer()
wnet = WordNetLemmatizer()
hspell = hunspell.HunSpell('Dict/en_US.dic', 'Dict/en_US.aff')
    
def stem_lemmatize(word):
    '''
        Uses Porter stemmer, hunspell and lemmatizer to stem, spell-check and
        lemmatize the word respectively. If the porter stemmer produces a valid
        word, the stemmed word is returned, else if the lemmatized word is valid,
        that is returned. If the above two fail, the word itself is returned.
    '''
    port_stem = port.stem(word)
    if hspell.spell(port_stem):           # If the word has a valid spelling
        return port_stem
    else:                                 # Stemmed word has invalid spelling
        lemma = wnet.lemmatize(word, 'v') # Lemmatizing as a verb is more accurate
        if hspell.spell(lemma): 
            return lemma

    # If all else fails, return the word itself
    return word


doc_tf = defaultdict(lambda:0)
token_pos = 0

def tokenizer(text):
    '''
        Tokenizes a line of text into its constituent tokens after 
        stemming/lemmatizing it. Lower(1)/Upper(2)/Mixed(3) case information is
        also retrieved and returned for each token.
    '''
    global doc_tf, token_pos
    #line_tokens = nltk.word_tokenize(text)
    line_tokens = wordpunct_tokenize(text) # Tokenizes based on special characters too
    modified_tokens = []
    capitalization = [] # 1 = lower, 2 = upper, 3 = mixed
    curr_pos = []
    
    for token in line_tokens:
        if(token.strip() != ""): # Don't parse tokens with only spaces
            try:
                tlower = token.lower()
                token_pos += 1
                if bool(re.match(r'^[s-z]', tlower)): # Change s-z to a-f, g-l, etc. based on which index is being created
                    modified_token = stem_lemmatize(tlower)
                    modified_tokens.append(modified_token)

                    # Extract case information of each token
                    if(token.islower()):
                        capitalization.append(1)
                    elif(token.isupper()):
                        capitalization.append(2)
                    else: # Mixed case
                        capitalization.append(3)

                    doc_tf[modified_token] += 1 # Compute term frequency within doc
                    curr_pos.append(token_pos)
                else:
                    continue
                
            except (UnicodeDecodeError, UnicodeEncodeError) as e:
                #print "Unicode Error: ", e
                continue
        else:
            print "Empty token"
    
    return modified_tokens, capitalization, curr_pos


### Parse HTML, tokenize the content and store important attributes
doc_words = dict()



## Scrape each document's content (tags and text), tokenize the text and index
## the terms
def walker(soup, path):
    global doc_words, token_pos
    if soup.name is not None:
        for child in soup.children:
            if type(child) is bs4.element.Tag:
                if(str(child.name) in ['script', 'style']): # Ignore script & style tags
                    continue
                
                try:
                    if (str(child.name) == 'meta' and child.attrs['name'] == 'keywords'):
                        #print child.attrs['content']
                        text = child.attrs['content']
                    else:
                        text = ''.join(child.findAll(text = True, recursive = False))
                    
                except KeyError:
                    # Retrieving the text in the tag
                    text = ''.join(child.findAll(text = True, recursive = False))
                    pass
                
                try:
                    # Getting font tag attributes
                    if str(child.name) == 'font':
                        if child.attrs['size'] != None:
                            word_font = child.attrs['size']

                    # Retrieving font attributes from other tags
                    elif child.has_attr('font'):
                        if child.attrs['font'] != None:
                            word_font = child.attrs['font']
                    else:
                        word_font = '-10' # Random font value 

                except KeyError:
                    word_font = '-10'
                    pass
                
                # Tokenize text
                if text != None: 
                    current_tokens, capitalization, curr_pos = tokenizer(text)
                    if len(current_tokens) > 0:
                        # Update values for each token 
                        for i in range(len(current_tokens)):
                            # Font, tag_name, path length, caps, pos
                            values = []
                            path_len = len(path.split('.')) - 1
                            values.extend((child.name, word_font, path_len, 
                                           capitalization[i], curr_pos[i]))
                            if current_tokens[i] not in doc_words:
                                doc_words[current_tokens[i]] = [values] # Store values alone
                            else:    
                                doc_words[current_tokens[i]].append(values)
                    
                # Recursive call to the children tags
                walker(child, path+"."+child.name)



## Call walker
invalid_ctr = 0 # Keep track of invalid files
i = 0
#doc_id = 1     # Initialize document id
doc_map = {}   # Map doc id to corresponding url

global token_pos
fancy_indexer.clear()
plain_indexer.clear()
N_docs = 0 # Number of docs in corpus

start_time = timer()
with open('Data/WEBPAGES_RAW/bookkeeping_valid.tsv', 'r') as f:
    for line in f:
        #i += 1
        #if(i > 10): # Index the first 100 files
        #    break
        url_line = (line.strip()).split('\t')
        urlline = url_line[1]
        doc_id = url_line[0]
        try:
            with open(str('Data/WEBPAGES_RAW/'+url_line[0]),'r') as curr_f:
                doc_content = curr_f.read() # Read file contents
        except KeyError:
            print "I/O error:", urlline
            continue

        soup=BeautifulSoup(doc_content, "lxml") # Parse file HTML
        path = ""
        doc_words.clear()         # Clear temporary doc content storage 
        token_pos = 0   # Initialize token position counter  
        #print doc_id,
        doc_map[doc_id] = urlline # Map document id to url
        try:
            walker(soup, path) # Extract tokens and other information in file
        except Exception as e:
            print e
            continue
        print doc_id,
        indexer(doc_id)    # Index the document tokens
        #doc_id += 1        # Increment document id
        N_docs += 1
        doc_tf.clear()     # Clear temporary doc term freq storage
        
end_time = timer()
print "Elapsed time = ", end_time - start_time, "seconds"

# Store the indices in memory
json.dump(fancy_indexer, open("Final_Indices/s-z_fancy.txt",'w'))
json.dump(plain_indexer, open("Final_Indices/s-z_plain.txt",'w'))




### Tokenize URLs

# Doc id to url mapping 
i = 0
doc_map = {}   # Map doc id to corresponding url
# N_docs = 0 # Number of docs in corpus

with open('Data/WEBPAGES_RAW/bookkeeping_valid.tsv', 'r') as f:
    for line in f:
        url_line = (line.strip()).split('\t')
        urlline = url_line[1]
        doc_id = url_line[0]
        doc_map[doc_id] = urlline # Map document id to url


url_tokens = defaultdict(dict)
def url_tokenize(d_id, url):
    '''
        Tokenizes a url into its constituent tokens
    '''
    global url_tokens
    curr_tokens = wordpunct_tokenize(url) # Tokenizes based on special characters too
    curr = defaultdict(lambda:0)
    dstr = str(d_id)
    
    for token in curr_tokens:
        if(token.strip() != ""): # Don't parse tokens with only spaces
            try:
                tlower = token.lower()
                modified_token = stem_lemmatize(tlower)
                if(dstr in url_tokens[token]):
                    url_tokens[modified_token][dstr] += 1
                else:
                    url_tokens[modified_token][dstr] = 1
            except (UnicodeDecodeError, UnicodeEncodeError) as e:
                #print "Unicode Error: ", e
                continue
        else:
            print "Empty token"

start_time = timer()
url_tokens.clear()
for docs in doc_map:
    url_tokenize(docs, doc_map[docs])

end_time = timer()
print "Elapsed time = ", end_time - start_time, "seconds"

# Store the final index
json.dump(url_tokens, open("Final_Indices/url_tokens.txt",'w'))


### Compute tf-idf
def compute_df(key):
    '''
        Computes the document frequency of each term in the fancy
        and plain indices and stores it in a separate dictionary
        'term_tf_df'
    '''
    tf_df = defaultdict(lambda:0)
    for i in range(len(fancy_indexer[key])):
        doc_id = str(fancy_indexer[key][i][0])
        #print doc_id, 
        if doc_id not in tf_df:
            tf_df[doc_id] = fancy_indexer[key][i][2]
    
    for i in range(len(plain_indexer[key])):
        doc_id = str(plain_indexer[key][i][0])
        if doc_id not in tf_df:
            tf_df[doc_id] = plain_indexer[key][i][2]
    
    term_tf_df[key] = tf_df

def compute_tf_idf(N):
    '''
        Computes the tf-idf score for each term in the term-doc 
        dictionary 'term_tf_df' and updates the dictionary in place
    '''
    for word in term_tf_df.keys():
        df = len(term_tf_df[word])
        for doc in term_tf_df[word]:
            tf_score = 1 + np.log10(term_tf_df[word][doc])  
            idf_score = np.log10(float(N_docs)/ df)
            # Replace term freq with idf in place
            term_tf_df[word][doc] = float(tf_score)*idf_score


# Compute document frequencies

term_tf_df = defaultdict(defaultdict)
term_tf_df.clear()
#i = 0

for key in list(chain.from_iterable([fancy_indexer.keys(), plain_indexer.keys()])):
    compute_df(key)

# Compute tf-idf scores: N_docs = number of docs in corpus
compute_tf_idf(N_docs)

# Print tf-idf
ctr = 0
for i in term_tf_df.keys():
    print i, term_tf_df[i].items()
    ctr += 1
    if ctr > 10:
        break

# Store the tf-idf index
json.dump(term_tf_df, open("Final_Indices/s-z_tfidf.txt",'w'))


## PageRank
from urlparse import urljoin

i = 0
#doc_id = 1     # Initialize document id
doc_map = {}   # Map doc id to corresponding url
inverse_doc_map = {} # Map url to corresponding doc id
N_docs = 0

with open('Data/WEBPAGES_RAW/bookkeeping_valid.tsv', 'r') as f:
    for line in f:
        url_lines = (line.strip()).split('\t')
        urllines = url_lines[1]
        doc_id = url_lines[0]
        doc_map[doc_id] = urllines # Map document id to url
        inverse_doc_map[urllines] = doc_id
        #doc_id += 1

print len(doc_map), len(inverse_doc_map)


i = 0
pagerank_map = defaultdict(dict) # Store incoming links (citations) to each link
pagerank_map.clear()

start_time = timer()
with open('Data/WEBPAGES_RAW/bookkeeping_valid.tsv', 'r') as f1:
    for line in f1:
        #i += 1
        #if i > 10:
        #    break
        #print i, 
        url_line = (line.strip()).split('\t')
        with open('Data/WEBPAGES_RAW/'+url_line[0]) as f2:
            doc_contents = f2.read()
            soup = BeautifulSoup(doc_contents, "lxml")
            a_list = soup.find_all('a') # Find all links in document
            for a in a_list:
                if a.has_attr('href') and not a.attrs['href'].startswith('#'):
                    new_url = urljoin(url_line[1], a.attrs['href']) # Convert relative to absolute url
                    if new_url in doc_map.values():
                        #print new_url, " ",
                        key_docid = inverse_doc_map[new_url]
                        val_docid = inverse_doc_map[url_line[1]]
                        if val_docid in pagerank_map[key_docid]:
                            pagerank_map[key_docid][val_docid] += 1
                        else:
                            pagerank_map[key_docid][val_docid] = 1
end_time = timer()
print "Elapsed time = ", (end_time - start_time), "seconds"

# Store the page rank index in memory
json.dump(pagerank_map, open("Final_Indices/pagerank_map.txt",'w'))

# Compute number of outgoing links in each url
out_links = defaultdict(lambda:0)
out_links.clear()
curr_count = 0
i = 0

with open('Data/WEBPAGES_RAW/bookkeeping_valid.tsv', 'r') as f1:
    for line in f1:
        i += 1
        #if i > 1000:
        #    break
        print i, 
        url_line = (line.strip()).split('\t')
        with open('Data/WEBPAGES_RAW/'+url_line[0]) as f2:
            curr_count = 0 # Re-initialize counter for each document
            doc_contents = f2.read()
            soup = BeautifulSoup(doc_contents, "lxml")
            a_list = soup.find_all('a') # Find all links in document
            for a in a_list:
                if a.has_attr('href') and not a.attrs['href'].startswith('#'):
                    curr_count += 1
            out_links[inverse_doc_map[url_line[1]]] = curr_count # Store number of links in dict

# Store in memory
json.dump(out_links, open("Final_Indices/outlinks.txt",'w'))
