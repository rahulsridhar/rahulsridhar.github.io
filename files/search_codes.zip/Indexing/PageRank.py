import numpy as np
import json
from timeit import default_timer as timer
from collections import defaultdict
import operator
import matplotlib.pyplot as plt
import re

## PageRank

# Load indices from memory (created in the indexing file)
pagerank_map = json.load(open("Final_Indices/pagerank_map.txt"))
out_links = json.load(open("Final_Indices/outlinks.txt"))

# Document-url mapping
i = 0
#doc_id = 1     # Initialize document id
doc_map = {}   # Map doc id to corresponding url
inverse_doc_map = {} # Map url to corresponding doc id

with open('Data/WEBPAGES_RAW/bookkeeping_valid.tsv', 'r') as f:
    for line in f:
        url_lines = (line.strip()).split('\t')
        urllines = url_lines[1]
        doc_id = url_lines[0]
        doc_map[doc_id] = urllines # Map document id to url
        inverse_doc_map[urllines] = doc_id

# Compute ranks
ranks = defaultdict()
def initialize_page_rank():
    for doc in pagerank_map:
        ranks[doc] = 1.

def compute_page_rank(damping = 0.85, threshold = 0.01, numIters = 10):
    '''
        Compute page ranks of each document
    '''
    initialize_page_rank() # Initialize ranks to 1
    curr_sum = 0
    j = 0
    for i in range(numIters):
        for doc in pagerank_map:
            curr_sum = 0
            for in_link in pagerank_map[doc]:
                try:
                    curr_sum += ranks[in_link]/out_links[in_link]
                except (KeyError, ZeroDivisionError) as e:
                    curr_sum += 0
            ranks[doc] = (1-damping) + damping*curr_sum

start_time = timer()
compute_page_rank(numIters=10)
end_time = timer()
print "Time elapsed = ", (end_time - start_time), "seconds."


# Highest, lowest and average rank
max_rank = max(ranks.values())
min_rank = min(ranks.values())
for key, value in ranks.items():
    if value == max_rank:
        print "Max_rank = ", max_rank, "; Key = ", key # 14942
print "Min_rank = ", min_rank # Has too many keys
print "Avg_rank = ", np.mean(ranks.values())


# Normalize values
for key, value in ranks.items():
    norm_val = (value - min_rank)/(max_rank-min_rank)
    ranks[key] = norm_val

# Store the normalized ranks
json.dump(ranks, open("Final_Indices/pagerank_values.txt",'w'))






