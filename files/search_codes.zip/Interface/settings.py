from collections import defaultdict
import json
from timeit import default_timer as timer

# Load document and inverse document maps (doc id --> url and url --> doc id)
def init():
	global doc_map
	global inverse_doc_map
	doc_map = {}   # Map doc id to corresponding url
	inverse_doc_map = {} # Map url to corresponding doc id

	with open('../Data/WEBPAGES_RAW/bookkeeping_valid.tsv', 'r') as f:
	    for line in f:
	        url_lines = (line.strip()).split('\t')
	        urllines = url_lines[1]
	        doc_map[url_lines[0]] = urllines # Map document id to url
	        inverse_doc_map[urllines] = url_lines[0]
