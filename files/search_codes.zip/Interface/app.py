import os
from collections import defaultdict
import json
import operator
import ranking2
from ranking2 import ranker
import settings
import bs4
from bs4 import BeautifulSoup
import nltk
from nltk.stem import porter, PorterStemmer, WordNetLemmatizer
import hunspell
from nltk.tokenize import wordpunct_tokenize
import copy
import numpy as np
import re
from flask import Flask, render_template
from flask import request, url_for
app = Flask(__name__)
import flask

# @app.route('/')
# def index():
#     return render_template('index.html')

#Create objects for stemmer, lemmatizer and spell checker
port = PorterStemmer()
wnet = WordNetLemmatizer()
hspell = hunspell.HunSpell('../Dict/en_US.dic', '../Dict/en_US.aff')
    
def stem_lemmatize(word):
    '''
        Uses Porter stemmer, hunspell and lemmatizer to stem, spell-check and
        lemmatize the word respectively. If the porter stemmer produces a valid
        word, the stemmed word is returned, else if the lemmatized word is valid,
        that is returned. If the above two fail, the word itself is returned.
    '''
    port_stem = port.stem(word)
    if hspell.spell(port_stem):           # If the word has a valid spelling
        return port_stem
    else:                                 # Stemmed word has invalid spelling
        lemma = wnet.lemmatize(word, 'v') # Lemmatizing as a verb is more accurate
        if hspell.spell(lemma): 
            return lemma

    # If all else fails, return the word itself
    return word



def tokenize(string):
    '''
        Tokenizes a url into its constituent tokens
    '''
    curr_tokens = wordpunct_tokenize(string) # Tokenizes based on special characters too
    curr = defaultdict(lambda:0)
    modified_tokens = []
    for token in curr_tokens:
        if(token.strip() != ""): # Don't parse tokens with only spaces
            try:
                tlower = token.lower()
                modified_token = stem_lemmatize(tlower)
                modified_tokens.append(modified_token)
            except (UnicodeDecodeError, UnicodeEncodeError) as e:
                #print "Unicode Error: ", e
                continue
        else:
            print "Empty token"
    return modified_tokens



@app.route('/', methods=['GET','POST'])
def hello():

	global doc_map
	if request.method=='POST':
                duplicate = defaultdict(lambda:0)
		settings.init()
		name=request.form['search']
		if len(name.strip())==0:
                        return render_template('home.html')
			#print "\nEmpty\n"
		print "Name: ",name

		#Call function, pass name
		tok_list=tokenize(name)
		doc_score=defaultdict(list)
		doc1_score=defaultdict(list)
		doc2_score=defaultdict(list)
		doc_score_general=defaultdict(list)
		
		total_doc_score=defaultdict(lambda: 0)

		text_pos=defaultdict(lambda: -1)
                
                # Separate analysis for bi-grams
                if len(tok_list) == 2:
                    try:
                        for i, tok in enumerate(tok_list):
                            doc_score.clear()
                            doc_score=ranking2.ranker(tok)
                            for doc in doc_score:
                                #print doc,doc_score[doc]
                                val=doc_score[doc][0]
                                total_doc_score[doc]+=val
                            if i==0: # First gram
                                doc1_score = copy.deepcopy(doc_score)
                            else: # Second gram
                                doc2_score = copy.deepcopy(doc_score)

                        count = 0 # Count intersection of docs in the two dicts
                        common_items = [] # Store common docs in both dicts
                        for item1 in doc1_score.items():
                            if item1[0] in doc2_score:
                                common_items.append(item1[0])
                                count += 1
                        print "Lengths of dicts = ", len(doc1_score), len(doc2_score), count

                        for item in common_items:
                            #print item, doc1_score[item], doc2_score[item],

                            # Postings don't have positions, only tfidf scores present
                            if len(doc1_score[item]) == 1 or len(doc2_score[item]) == 1: 
                                #print "No positions"
                                continue

                            #else do
                            count_bigram = 0 # Count number of bigrams in each doc                    
                            
                            # Traverse and compare positions of both lists
                            for pos1 in range(1, len(doc1_score[item])): # Position is from second index
                                for pos2 in range(1, len(doc2_score[item])):
                                    gram1 = doc1_score[item][pos1]
                                    gram2 = doc2_score[item][pos2]
                                    if np.abs(gram1 - gram2) == 1:
                                        #print "Yay !!!!!!"
                                        if item not in text_pos:
                                            #print item
                                            text_pos[item]=gram1
                                        count_bigram += 1
                                        #total_doc_score[item] += 5
                                        break
                                    else:
                                        continue
                                        #print "No -----"
                            # Increment corresponding doc's score
                            if count_bigram != 0:
                                total_doc_score[item] += 6 + np.log10(0.00001 + count_bigram)
                    except Exception as e: # Query not found
                            return render_template('search.html', name = name)

                else: # If < or > two tokens in input query
                    for tok in tok_list:
                        try:
                            doc_score_general=ranking2.ranker(tok)
                                #print doc_score_general
                            for doc in doc_score_general:
                                #print doc,doc_score_general[doc]
                                val=doc_score_general[doc][0]
                                total_doc_score[doc]+=val
                        except Exception as e: # Query not found
                            return render_template('search.html', name = name)
                            
                                   
                    
		sorted_x = sorted(total_doc_score.items(), key=operator.itemgetter(1), reverse=True)
                #print sorted_x

		res_list=[item[0] for item in sorted_x]	
		res_URL_list=[]
		res_title_list=[]
		res_snippet=[]
		j=0
		toks = ' '.join(str(elem) for elem in tok_list)
		#print "Toks = ", toks
		for i in res_list[:20]:
                        link = unicode(settings.doc_map[i], 'utf-8')
                        if link.lower() not in duplicate:
                            res_URL_list.append(link)
                            duplicate[link] = 1
                        else:
                            continue
			f=open('../Data/WEBPAGES_RAW/'+i,'r')
			r=f.read().decode('utf-8')
			#f.close()
			
			soup = BeautifulSoup(r, 'lxml')
			soup_text=soup.get_text()

                        # Extract title
			try:
                            title_text = soup.title.string
                            res_title_list.append(title_text)
                        except Exception as e:
                            res_title_list.append(name)                            
                                
			start=0
			end=len(soup_text)
                        if i in text_pos:
                            #pos=soup_text.find(name)
                            try:
                                pos = re.search('\\b%s\\b'%name.lower(), soup_text.lower()).start()
                            except Exception as e:
                                print "Exception = ", e
                                pos = -1
                                
                            if pos == -1:
                                pos = soup_text.find(name)
                                
                            if pos>100:
                                    start=pos-100
                            if pos+100<end:
                                    end=pos+100
                            text=soup_text[start:end]
                            text=re.sub(r'[\s]{2,}|[\t]|\n',' ',text)

                            try:
                                    #s=text.find(name)
				    #snip=flask.Markup(text[:s]+'<b>'+name.lower()+'</b>'+text[s+len(name):])
				    #print "Snip1 = ", snip 
                                    #res_snippet.append(snip.strip())
                                    res_snippet.append(text.strip())
                            except (UnicodeEncodeError, UnicodeDecodeError) as e:
                                    res_snippet.append('EMPTY')
                                    #print "exception = ", e
                                    pass
			else:
				mark=1
				name_words=name.split()
				for i in range(len(tok_list)):
					#pos=soup_text.find(name_words[i])
                                        try:
                                            pos = re.search('\\b%s\\b'%name_words[i].lower(), soup_text.lower()).start()
                                        except:
                                            pos = -1
					#print "POS: ",pos
					if pos==-1 or pos is None:
						continue
					else:
						if pos>100:
							start=pos-100
						if pos+100<end:
							end=pos+100
						text=soup_text[start:end]
						text=re.sub(r'[\s]{2,}|[\t]|\n',' ',text)
						try:
                                                        #s=text.find(name_words[i])
                                                        #snip=flask.Markup(text[:s]+'<b>'+name_words[i]+'</b>'+text[s+len(name_words[i])-1:])
                                                        #print "Snip2 = ", snip
							res_snippet.append(text.strip())
                                                        #res_snippet.append(snip.strip())
							mark=0
							break
						except (UnicodeDecodeError, UnicodeEncodeError) as e:
                                                        #print "exception = ", e                                                    
							pass
				if mark==1:
					res_snippet.append('...[text snippet unavailable]...')
			

		# Send top k results
		#print "Top results:"
		#for i in range(len(res_URL_list)):
                #    print str(res_URL_list[i]), "\n"
                #print len(res_URL_list), len(res_title_list), len(res_snippet)
		return render_template('result.html', name = name, res_list = zip(res_URL_list[:20], res_title_list[:20], res_snippet[:20]))
	else:
		return render_template('home.html')

if __name__ == '__main__':
	app.run()
