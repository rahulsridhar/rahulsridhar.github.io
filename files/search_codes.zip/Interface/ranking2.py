#Load files
from collections import defaultdict
import app
import settings
import re
from timeit import default_timer as timer
import json
import numpy as np

#Load files

start_time = timer()
af_fancy_index = json.load(open('../Final_Indices/a-f_fancy.txt'))
af_tfidf = json.load(open('../Final_Indices/a-f_tfidf.txt'))
gl_fancy_index = json.load(open('../Final_Indices/g-l_fancy.txt'))
gl_tfidf = json.load(open('../Final_Indices/g-l_tfidf.txt'))
mr_fancy_index = json.load(open('../Final_Indices/m-r_fancy.txt'))
mr_tfidf = json.load(open('../Final_Indices/m-r_tfidf.txt'))
sz_fancy_index = json.load(open('../Final_Indices/s-z_fancy.txt'))
sz_tfidf = json.load(open('../Final_Indices/s-z_tfidf.txt'))
url_tokens=json.load(open('../Final_Indices/url_tokens.txt'))
pagerank = json.load(open("../Final_Indices/pagerank_values.txt"))
end_time = timer()
print "Time elapsed = ", (end_time - start_time), "seconds"


#Get index name
def index_name(term):
    tlower = term.lower()
    if bool(re.match(r'^[a-f]', tlower)):
        return "af_tfidf", "af_fancy_index" 
    elif bool(re.match(r'^[g-l]', tlower)):
        return "gl_tfidf", "gl_fancy_index" 
    elif bool(re.match(r'^[m-r]', tlower)):
        return "mr_tfidf", "mr_fancy_index" 
    elif bool(re.match(r'^[s-z]', tlower)):
        return "sz_tfidf", "sz_fancy_index" 

#Get url tokens
def in_urltokens(term):
    global url_tokens
    url_scores = defaultdict(lambda:0)
    if term in url_tokens:
        for doc in url_tokens[term]: # Weight url based on its length
            url_scores[doc] = (120. + len(term))/len(settings.doc_map[doc])
    return url_scores

#Get title stuff
def in_title(term, doc_set, fancy_index):
    ret_doc_list = defaultdict(list)
    #print fancy_index
    if term not in globals()[fancy_index]:
        return ret_doc_list
    for doc in globals()[fancy_index][term]:
        if doc[1][0] == 'title':
            if doc[0] not in ret_doc_list: # Doc not already scored. Score for first time.
                if str(doc[0]) in doc_set:
                    ret_doc_list[doc[0]].append(doc_set[doc[0]] + 5)
                else:
                    ret_doc_list[doc[0]].append(5)
                ret_doc_list[doc[0]].append(doc[1][4]) # Append position
            else: # Doc already scored. Append new position alone
                ret_doc_list[doc[0]].append(doc[1][4])

    for doc in doc_set:
        if doc not in ret_doc_list:
            ret_doc_list[doc].append(doc_set[doc]) # Append url score alone
    return ret_doc_list

# Checks if token is in any special tag and scores accordingly
def in_special_tag(term, doc_set, fancy_index):
    ret_doc_list = defaultdict(list)
    tag_list = ['meta', 'title', 'h1', 'h2', 'h3', 'h4', 'table', 'th', 'b', 'a']
    score_list = [3, 5, 2, 1.5, 1, 0.5, 1, 1, 0.1, 0.1]
    #score_list = [3, 5, 4, 3, 2, 1, 1, 2, 2, 3]
    n = len(tag_list)
    count_list = np.zeros(n) # Initialize count list
    prev_doc = ''
    
    if term not in globals()[fancy_index]:
        return ret_doc_list

    #print "\n\nDoc"
    for doc in globals()[fancy_index][term]:
        try:
            tag_ind = tag_list.index(doc[1][0]) # Get the index of tag from tag list
            score = score_list[tag_ind]
            
            if doc[0] not in ret_doc_list:  # Doc not already scored ==> score for first time
                
                # Before that, score the previous document first (docs in dict are sorted, so when 
                # the function passes this if condition, the previous doc has been processed completely)
                
                if prev_doc != '':
                    prev_doc_score = 3*np.log10(1 + np.sum(count_list*score_list))
                    #print "\nPrev score = ", prev_doc_score
                    ret_doc_list[prev_doc][0] += prev_doc_score
                    prev_doc = ''

                count_list = np.zeros(n) # Re-initialize count list
                
                if doc[0] in doc_set: # If tag was found in url tokens as well
                    ret_doc_list[doc[0]].append(doc_set[doc[0]] + score)
                else: # Else, add only the tag's score
                    ret_doc_list[doc[0]].append(score)
                ret_doc_list[doc[0]].append(doc[1][4]) # Append position
            
            else: # Doc already scored ==> count number of tag occurrences and append new position
                count_list[tag_ind] += 1
                ret_doc_list[doc[0]].append(doc[1][4])
                prev_doc = doc[0]

        except: # Tag not in special tag list    
            continue
            

    for doc in doc_set:
        if doc not in ret_doc_list: # Doc not in fancy index, but have to include its url token score
            ret_doc_list[doc].append(doc_set[doc]) # Append url score alone
    return ret_doc_list


#Ranker
def ranker(term):
    '''
        Ranks documents based on urltokens, title and tfidf
    '''
    term_doc_score = defaultdict(lambda:0)
    url_scores = in_urltokens(term)
    ind_names = index_name(term) # tf-idf, fancy index
    url_scores2 = in_special_tag(term, url_scores, ind_names[1])
    
    # Search tf-idf
    if term not in globals()[ind_names[0]]:
        return "term not found"
    for doc in globals()[ind_names[0]][term]:
        if doc in url_scores2: # Update score if term is already present in index
            url_scores2[doc][0] +=  1.3*globals()[ind_names[0]][term][doc]
        else:
            url_scores2[doc].append(1.3*globals()[ind_names[0]][term][doc])
            
        if doc in pagerank: 
            url_scores2[doc][0] +=  5.5 + np.log10(0.000001 + pagerank[doc])
    
    return url_scores2
