#!/usr/bin/env python

import datetime as dt
import json, sys
from apiclient.discovery import build


# REFERENCE: http://scriptsonscripts.blogspot.com/2015/02/python-google-search-api-requests.html

def query(term):
    # Create an output file name in the format "srch_res_yyyyMMdd_hhmmss.json"
    now_sfx = dt.datetime.now().strftime('%Y%m%d_%H%M%S')
    output_dir = './output/'
    output_fname = output_dir + term.split(' ')[0] + '.json'
    print "TERM: ", term

    search_term = term
    num_requests = 1

    # Key codes we created earlier for the Google CustomSearch API
    search_engine_id = '012649029267536420554:m5dc8jxawdg'
    api_key = 'AIzaSyCRIhYl43wxKzUX5jPSHSkDQnt46cquKYg'
    
    # The build function creates a service object. It takes an API name and API 
    # version as arguments. 
    service = build('customsearch', 'v1', developerKey=api_key)
    # A collection is a set of resources. We know this one is called "cse"
    # because the CustomSearch API page tells us cse "Returns the cse Resource".
    collection = service.cse()

    output_f = open(output_fname, 'wb')

    for i in range(0, num_requests):
        # This is the offset from the beginning to start getting the results from
        start_val = 1 + (i * 10)
        # Make an HTTP request object
        request = collection.list(q=search_term,
            num=10, #this is the maximum & default anyway
            start=start_val,
            cx=search_engine_id
        )
        response = request.execute()
        #print "RESPONSE: ", response
        output = json.dumps(response, sort_keys=True, indent=2)
        output_f.write(output)
        print('Wrote 10 search results...')

    output_f.close()
    print('Output file "{}" written.'.format(output_fname))
    
