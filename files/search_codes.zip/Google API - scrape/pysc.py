import read_google
import search_google

querylist=['cristina lopes site:ics.uci.edu','mondego','machine learning','software engineering','security','student affairs',\
    'graduate courses','Crista Lopes','REST','computer games','information retrieval']
for q in querylist:
    search_google.query(q)
read_google.output()