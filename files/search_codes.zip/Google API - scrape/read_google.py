import json
import os

def output():	
	for file in os.listdir('output'):
		filepath='output/'+file
		jsonFile = open(filepath, 'r')
		values = json.load(jsonFile)
		linklist=[]
		print filepath
		print len(values["items"])
		for i in range(len(values["items"])):
			linklist.append(values["items"][i]["link"])
		for val in linklist:
				print val
		print "\n"
		#print values["items"][0]
		jsonFile.close()