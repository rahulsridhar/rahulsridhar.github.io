# CS 243 - Test Synthpop - generating synthetic data ----------------------
# https://cran.r-project.org/web/packages/synthpop/vignettes/synthpop.pdf

library("synthpop")

# Read data
data <- read.csv('Intermediate/data_train.csv')
View(data)
data <- data[, -1] # Drop first column (irrelevant)

syn.seed <- 10

# Generate data samples
# k=number of data points required - default = number of input data samples
#syn.data.obj <- syn(data, seed=syn.seed, k=1500) 
syn.data.obj <- syn(data, seed=syn.seed) 

# View generated data
syn.data <- syn.data.obj$syn
str(syn.data)
sum(syn.data$Vectorizable)

# Store the generated data
write.csv(syn.data, 'Intermediate/syn_data2.csv')